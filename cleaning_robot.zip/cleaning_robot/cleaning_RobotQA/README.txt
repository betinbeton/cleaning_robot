To execute the cleaning_robot


***You need .net core 2.*

command to execute the app

dotnet cleaning_robot_QA.dll


NOTE: You can change the folder where the test.json file are in the appsettings.json

path where the file are, please use the \\ to change folder

"pathFolderQA": "D:\\c#\\MyQ Coding Test - Roomba Robot\\cleaning_robot\\cleaning_RobotQA\\QA_Cleaning_Robot"

url of the api you only need to change the localhost:38984

"url": "http://localhost:38984/Cleaning_Robot/start/"