﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cleaning_Robot_Lib
{
    /// <summary>
    /// Objet use to create Json Response
    /// Where the robot visited
    /// </summary>
    public class Visited
    {

        public int X { get; set; }
        public int Y { get; set; }

    }
}
