﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cleaning_Robot_Lib
{
    public class Cleaned
    {
        public int X { get; set; }
        public int Y { get; set; }
    }
}
