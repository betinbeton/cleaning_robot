To execute the cleaning_robot


***You need .net core 2.*

command to execute the app

dotnet cleaning_robot.dll source.json result.json


NOTE: You can change the name in the arg for example

dotnet cleaning_robot.dll test1.json result.json

dotnet cleaning_robot.dll test1.json test1result.json